<?php
/**
 * ! $nizSvihStranica = add all pages in this array
 */

$nizSvihStranica = [
    ['galerija_ikona.php', 'Галерија&nbsp;Икона'],
    ['galerija_slika.php', 'Галерија&nbsp;Слика'],
    ['biografija.php', 'Биографија']
];
$currentPage = basename($_SERVER['PHP_SELF']);