<?php
require_once "head.php";
require_once "header.php";
?>
<main>
    <div class="wrapper">
        <div id="404" style="margin-top: 40%">
            <h1 style="text-align: center">Страница није пронађена!</h1>
            <p style="text-align: center"><a class="active" href="galerija_ikona.php">Кликните овде за одлазак на почетну страницу!</a></p>
        </div>
    </div>
</main>
</body>
</html>