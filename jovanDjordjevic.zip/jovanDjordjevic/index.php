<?php
header("Location: galerija_ikona.php");