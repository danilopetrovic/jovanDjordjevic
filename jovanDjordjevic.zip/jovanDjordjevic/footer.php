<footer id="footer">
    <div class="wrapper wrapper-footer nav">
        <div id="gmaps-iframe">
            <iframe width="100%" height="400px" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1543.9777141970808!2d20.535016881187197!3d44.78758248404469!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a70a8f07c4ad3%3A0xf0126810026f2568!2sVojina%20%C4%90ura%C5%A1inovi%C4%87a-Kostje%2031%2C%20Beograd!5e0!3m2!1sen!2srs!4v1704066837889!5m2!1sen!2srs" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <a id="kakoDoNas" target="_blank" href="https://maps.app.goo.gl/Z7XmvrGH7PBt3gA18">Навигација</a>
        </div>
        <nav id="contact-info">
            <ul>
                <li><a target="_blank" href="https://maps.app.goo.gl/Z7XmvrGH7PBt3gA18"><i class="fa-solid fa-map-location-dot"></i> Ул. Војина Ђурашиновића 31, Миријево, 11000 Београд</a></li>
                <li><a href="tel:+38163/71-87-115"><i class="fa-solid fa-mobile-screen"></i> 063/71-87-115</a></li>
                <li><a href="mailto:sabljabg@gmail.com"><i class="fa-solid fa-envelope"></i> Пошаљите нам "e-mail"</a></li>
            </ul>
        </nav>
        <p id="prava">&copy; Сва права резервисана.</p>
    </div>
</footer>